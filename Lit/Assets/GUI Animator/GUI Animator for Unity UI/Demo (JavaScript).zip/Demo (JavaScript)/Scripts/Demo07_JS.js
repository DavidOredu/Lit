// GUI Animator for Unity UI
// Version: 1.2.0
// Compatilble: Unity 2017.1.0f3 or higher, more info in Readme.txt file.
//
// Developer:				Gold Experience Team (https://assetstore.unity.com/publishers/4162)
// Unity Asset Store:		https://assetstore.unity.com/packages/tools/gui/gui-animator-for-unity-ui-28709
//
// Please direct any bugs/comments/suggestions to geteamdev@gmail.com.

// ######################################################################
// Demo07_JS class
// - Animates all GAui elements in the scene.
// - Responds to user mouse click or tap on buttons.
//
// Note this class is attached with "-SceneController-" object in "GA UUI JS - Demo07 (960x600px)" scene.
// ######################################################################

class Demo07_JS extends MonoBehaviour {

	// ########################################
	// Variables
	// ########################################

    // Canvas
    var m_Canvas : Canvas;
	
   // GUIAnim objects of title text
    var m_Title1 : GAui;
    var m_Title2 : GAui;
	
   // GUIAnim objects of top and bottom bars
    var m_TopBar : GAui;
    var m_BottomBar : GAui;
	
   // GUIAnim object of dialogs
    var m_Dialog : GAui;
    var m_DialogButtons : GAui;
	
   // GUIAnim objects of buttons
    var m_Button1 : GAui;
    var m_Button2 : GAui;
    var m_Button3 : GAui;
    var m_Button4 : GAui;
	
	// ########################################
	// MonoBehaviour Functions
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.html
	// ########################################
	
	// Awake is called when the script instance is being loaded.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Awake.html
   function Awake () {
       if(enabled)
       {
		// Set GSui.Instance.m_AutoAnimation to false in Awake(), let you control all GUI Animator elements in the scene via scripts.
		GSui.Instance.m_AutoAnimation = false;
       }
   }
	
	// Start is called on the frame when a script is enabled just before any of the Update methods is called the first time.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Start.html
        function Start () {
            // MoveIn m_TopBar and m_BottomBar
            m_TopBar.MoveIn(GSui.eGUIMove.SelfAndChildren);
            m_BottomBar.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
            // MoveIn m_Title1 and m_Title2
            StartCoroutine(MoveInTitleGameObjects());
		
            // Disable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
            GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, false);
        }
	
	// Update is called every frame, if the MonoBehaviour is enabled.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Update.html
        function Update () {
		
        }
	
	// ########################################
	// MoveIn/MoveOut functions
	// ########################################
	
        // MoveIn m_Title1 and m_Title2
        function MoveInTitleGameObjects () : IEnumerator {
            yield  WaitForSeconds(1.0f);
		
            // MoveIn m_Title1 and m_Title2
            m_Title1.MoveIn(GSui.eGUIMove.Self);
            m_Title2.MoveIn(GSui.eGUIMove.Self);
		
            // MoveIn all dialogs and buttons
            StartCoroutine(MoveInPrimaryButtons());
        }
	
            // MoveIn all dialogs and buttons
            function MoveInPrimaryButtons () : IEnumerator {
                yield  WaitForSeconds(1.0f);
		
                // MoveIn all dialogs
                m_Dialog.MoveIn(GSui.eGUIMove.SelfAndChildren);
                m_DialogButtons.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
                // MoveIn all buttons
                m_Button1.MoveIn(GSui.eGUIMove.SelfAndChildren);	
                m_Button2.MoveIn(GSui.eGUIMove.SelfAndChildren);	
                m_Button3.MoveIn(GSui.eGUIMove.SelfAndChildren);	
                m_Button4.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
                // Enable all scene switch buttons
                StartCoroutine(EnableAllDemoButtons());
            }
	
                // MoveOut all dialogs and buttons
                function HideAllGUIs () {
                    // MoveOut all dialogs
                    m_Dialog.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_DialogButtons.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                    // MoveOut all buttons
                    m_Button1.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_Button2.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_Button3.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_Button4.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                    // MoveOut m_Title1 and m_Title2
                    StartCoroutine(HideTitleTextMeshes());
                }
	
                // MoveOut m_Title1 and m_Title2
                function HideTitleTextMeshes () : IEnumerator {
                    yield  WaitForSeconds(1.0f);
		
                    // MoveOut m_Title1 and m_Title2
                    m_Title1.MoveOut(GSui.eGUIMove.Self);
                    m_Title2.MoveOut(GSui.eGUIMove.Self);
		
                    // MoveOut m_TopBar and m_BottomBar
                    m_TopBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_BottomBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                }
	
                    // ######################################################################
                    // Enable/Disable button functions
                    // ######################################################################
	
                    // Enable/Disable all scene switch Coroutine
                    function EnableAllDemoButtons () : IEnumerator {
                        yield  WaitForSeconds(1.0f);
		
                        // Enable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
                        GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, true);
                    }

                        // Disable all buttons for a few seconds
                        function DisableButtonForSeconds ( GO : GameObject ,   DisableTime : float) {
                            // Disable all buttons
                            GSui.Instance.EnableButton(GO.transform, false);
		
                            yield  WaitForSeconds(DisableTime);
		
                            // Enable all buttons
                            GSui.Instance.EnableButton(GO.transform, true);
                        }
	
	// ########################################
	// UI Responder functions
	// ########################################
	
                            function OnButton_1 () {
                                // MoveOut m_Button1
                                MoveButtonsOut();
		
                                // Disable m_Button1, m_Button2, m_Button3, m_Button4 for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_Button1.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button2.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button3.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button4.gameObject, 2.0f));

                                // Set next move in of m_Button1 to new position
                                StartCoroutine(SetButtonMove(GUIAnim.ePosMove.UpperScreenEdge, GUIAnim.ePosMove.UpperScreenEdge));
                            }
	
                            function OnButton_2 () {
                                // MoveOut m_Button2
                                MoveButtonsOut();
		
                                // Disable m_Button1, m_Button2, m_Button3, m_Button4 for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_Button1.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button2.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button3.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button4.gameObject, 2.0f));
		
                                // Set next move in of m_Button2 to new position
                                StartCoroutine(SetButtonMove(GUIAnim.ePosMove.LeftScreenEdge, GUIAnim.ePosMove.LeftScreenEdge));
                            }
	
                            function OnButton_3 () {
                                // MoveOut m_Button3
                                MoveButtonsOut();
		
                                // Disable m_Button1, m_Button2, m_Button3, m_Button4 for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_Button1.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button2.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button3.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button4.gameObject, 2.0f));

                                // Set next move in of m_Button3 to new position
                                StartCoroutine(SetButtonMove(GUIAnim.ePosMove.RightScreenEdge, GUIAnim.ePosMove.RightScreenEdge));
                            }
	
                            function OnButton_4 () {
                                // MoveOut m_Button4
                                MoveButtonsOut();
		
                                // Disable m_Button1, m_Button2, m_Button3, m_Button4 for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_Button1.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button2.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button3.gameObject, 2.0f));
                                StartCoroutine(DisableButtonForSeconds(m_Button4.gameObject, 2.0f));
		
                                // Set next move in of m_Button3 to new position
                                StartCoroutine(SetButtonMove(GUIAnim.ePosMove.BottomScreenEdge, GUIAnim.ePosMove.BottomScreenEdge));
                            }
	
                            function OnDialogButton () {
                                // MoveOut m_Dialog
                                m_Dialog.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                m_DialogButtons.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                                // Disable m_DialogButtons for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_DialogButtons.gameObject, 2.0f));

                                // Moves m_Dialog back to screen
                                StartCoroutine(DialogMoveIn());
                            }
	
	// ########################################
	// Move Dialog/Button functions
	// ########################################
	
                            // MoveOut all buttons
                            function MoveButtonsOut () {
                                m_Button1.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                m_Button2.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                m_Button3.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                m_Button4.MoveOut(GSui.eGUIMove.SelfAndChildren);
                            }
	
                            // Set next move in of all buttons to new position
                            function SetButtonMove ( PosMoveIn : GUIAnim.ePosMove ,   PosMoveOut : GUIAnim.ePosMove  ) : IEnumerator {
                                yield  WaitForSeconds(2.0f);
		
                                // Set next MoveIn position of m_Button1 to PosMoveIn
                                m_Button1.m_MoveIn.MoveFrom = PosMoveIn;
                                // Reset m_Button1
                                m_Button1.Reset();
                                // MoveIn m_Button1
                                m_Button1.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
                                // Set next MoveIn position of m_Button2 to PosMoveIn
                                m_Button2.m_MoveIn.MoveFrom = PosMoveIn;
                                // Reset m_Button2
                                m_Button2.Reset();
                                // MoveIn m_Button2
                                m_Button2.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
                                // Set next MoveIn position of m_Button3 to PosMoveIn
                                m_Button3.m_MoveIn.MoveFrom = PosMoveIn;
                                // Reset m_Button3
                                m_Button3.Reset();
                                // MoveIn m_Button3
                                m_Button3.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
                                // Set next MoveIn position of m_Button4 to PosMoveIn
                                m_Button4.m_MoveIn.MoveFrom = PosMoveIn;
                                // Reset m_Button4
                                m_Button4.Reset();
                                // MoveIn m_Button4
                                m_Button4.MoveIn(GSui.eGUIMove.SelfAndChildren);
                            }
	
                                // Moves m_Dialog back to screen
                                function DialogMoveIn () : IEnumerator {
                                    yield  WaitForSeconds(1.5f);
		
                                    m_Dialog.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                    m_DialogButtons.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                }
